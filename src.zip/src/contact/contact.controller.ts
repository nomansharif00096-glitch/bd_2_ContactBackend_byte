import { Body, Controller, Post } from '@nestjs/common';
import { ContactService } from './contact.service';
import { CreateContactDto } from './dto/createContactDto.dto';

@Controller('contact')
export class ContactController {
    constructor(private readonly contactService: ContactService){}

    @Post('form')
    async formSubmission(@Body() body : CreateContactDto){
        return await this.contactService.formSubmission(body);
    }
}
