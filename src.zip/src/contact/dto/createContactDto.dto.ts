import { IsEmail, IsNotEmpty, MaxLength } from "class-validator";

export class CreateContactDto{
    @IsNotEmpty()
    @MaxLength(25)
    name! : string;

    @IsEmail()
    @IsNotEmpty()
    email! : string;
    
    @IsNotEmpty()
    @MaxLength(100)
    message! : string;
}
