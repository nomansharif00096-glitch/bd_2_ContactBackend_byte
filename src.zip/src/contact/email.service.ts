import { Injectable, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
// import  { Transporter } from "nodemailer";
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailService {
    private readonly transporter: nodemailer.Transporter;
    
    constructor(private readonly configService: ConfigService){
        this.transporter = nodemailer.createTransport({
            host: this.configService.getOrThrow<string>('SMTP_HOST'),
            port: Number(this.configService.getOrThrow<string>('SMTP_PORT')),
            secure: Number(this.configService.getOrThrow<string>('SMTP_PORT'))===465,
            auth:{
                user: this.configService.getOrThrow<string>('SMTP_USER'),
                pass: this.configService.getOrThrow<string>('SMTP_PASS'),
            }
        });
    }

    async sendingEmail(
        name : string,
        email: string,
        message : string,
        relayAddress : string
    ){
        try{
            const info = await this.transporter.sendMail({
                from: `"${relayAddress}" <${this.configService.getOrThrow<string>('MAIL_FROM')}>`,
                replyTo: email,
                to: this.configService.getOrThrow<string>('CONTACT_RECEIVER'),
                subject: `New contact message - ${relayAddress}`,
                text: [
                    `Name: ${name}`,
                    `Relay identity: ${relayAddress}`,
                    '',
                    'Message:',
                    message,
                ].join('\n'),
            });

            return {
                messageId: info.messageId,
                accepted: info.accepted,
            };
        }catch(error){
            console.error(error);
            throw new ServiceUnavailableException({
                success: false,
                message: 'Your message could not be delivered. Please try again later.'
            });
        }
    }

    async verifyConnection(){
        await this.transporter.verify();
    }
}