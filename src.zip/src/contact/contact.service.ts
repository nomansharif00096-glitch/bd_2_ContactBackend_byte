import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateContactDto } from './dto/createContactDto.dto';
import { randomBytes, randomUUID } from 'crypto';
import { join } from 'path';
import { mkdir,appendFile } from 'fs/promises';
import { EmailService } from './email.service';
@Injectable()
export class ContactService {
    constructor(private readonly emailService: EmailService){}
    // Form Submission
    async formSubmission(createContactDto: CreateContactDto){
        try{
            // Hashing the email address
            const hashedEmail = randomBytes(10).toString('hex');
            const relayAddress = `relay-${hashedEmail}@burner.local`

            // Sending mail
            this.emailService.verifyConnection();
            const delivery = await this.emailService.sendingEmail(
                createContactDto.name,
                createContactDto.email,
                createContactDto.message,
                relayAddress
            );

            // JSON data storage
            const storedAt = new Date().toISOString();
            const id = randomUUID();

            const record = {
                id,
                name:createContactDto.name,
                relayAddress,
                message: createContactDto.message,
                storedAt,
                delivery:{
                    status: 'sent',
                    messageId: delivery.messageId,
                    accepted: delivery.accepted,
                }
            };

            const dataDirectory = join(process.cwd(), 'src/data');
            const storagePath = join(dataDirectory, 'submissions.jsonl');

            await mkdir(dataDirectory, { recursive: true });
            await appendFile(
                    storagePath,
                    `${JSON.stringify(record)}\n`,
                    'utf8'
                );
            // Sending successfull response    
            return {
                success: true,
                message: "Submission received and stored successfully.",
                "submissions":{
                    "id":id,
                    "relayAddress": relayAddress,
                    "storedAt":storedAt
                },  
            }
        }catch(error){
            throw new InternalServerErrorException({
                success: false,
                message: "Can not submit form data, please try again!"
            });
        }
    }
}
