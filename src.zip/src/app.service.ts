import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  starting(): string {
    return 'Contact-From-Backend Application!';
  }
}
